﻿Public Class tuile

    Public Img As Bitmap
    Public Position As Point
    Public Type As Int16

End Class
